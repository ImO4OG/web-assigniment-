-- UCU Campus Lost-and-Found: database schema (MySQL 5.7+/8, MariaDB 10.2+, TiDB MySQL-compatible)
-- Run it with:  npm run db:init   (inside /backend, reads your .env)   -- or --
--               mysql -u root -p < database/schema.sql
-- It creates the database if needed and RE-CREATES the tables: re-running it ERASES the data in them.
-- TiDB Cloud: if your user may not create databases, delete the next two statements and run the rest in your database.

CREATE DATABASE IF NOT EXISTS ucu_lost_found CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ucu_lost_found;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS claims;
DROP TABLE IF EXISTS reports;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  full_name     VARCHAR(100) NOT NULL,
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,            -- bcrypt hash, never plain text
  role          ENUM('student','admin') NOT NULL DEFAULT 'student',
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Server-side sessions: logging out DELETES the row, so the token stops working at once.
CREATE TABLE sessions (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  token_hash  CHAR(64) NOT NULL UNIQUE,            -- SHA-256 of the token (raw token is never stored)
  expires_at  DATETIME NOT NULL,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE reports (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  user_id         INT NOT NULL,
  type            ENUM('lost','found') NOT NULL,
  title           VARCHAR(120) NOT NULL,
  category        VARCHAR(50)  NOT NULL,
  description     TEXT NOT NULL,                   -- PUBLIC
  private_details TEXT NULL,                       -- reporter + admin ONLY (found items)
  event_date      DATE NOT NULL,
  location        VARCHAR(100) NOT NULL,
  photo_url       VARCHAR(500) NULL,
  status          ENUM('open','returned') NOT NULL DEFAULT 'open',
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  INDEX idx_type (type),
  INDEX idx_category (category),
  INDEX idx_location (location),
  INDEX idx_event_date (event_date),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE claims (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  report_id     INT NOT NULL,
  claimant_id   INT NOT NULL,
  evidence      TEXT NOT NULL,                     -- PRIVATE: claimant + admin only
  status        ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  admin_reason  VARCHAR(500) NULL,
  reviewed_by   INT NULL,
  reviewed_at   DATETIME NULL,
  returned_at   DATETIME NULL,                     -- set only when collection is confirmed
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  -- Database-level guarantee: at most ONE approved claim per report.
  approved_report_id INT GENERATED ALWAYS AS (IF(status = 'approved', report_id, NULL)) STORED,
  UNIQUE KEY uniq_one_approved_per_report (approved_report_id),
  FOREIGN KEY (report_id)   REFERENCES reports(id),
  FOREIGN KEY (claimant_id) REFERENCES users(id),
  FOREIGN KEY (reviewed_by) REFERENCES users(id),
  INDEX idx_claim_report (report_id),
  INDEX idx_claim_claimant (claimant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
